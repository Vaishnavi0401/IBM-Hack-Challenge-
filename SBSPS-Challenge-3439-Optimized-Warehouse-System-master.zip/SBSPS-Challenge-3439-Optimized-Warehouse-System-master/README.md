# SBSPS-Challenge-3439-Optimized-Warehouse-System
Using Random Forest Regressor Model 
Find the json file and ipynb file for the code.
Obtain the predictions of the number of orders according to the input.
Find the ppt for reference.
The video link:
https://photos.google.com/share/AF1QipP5zugJzH8farSfuynfSOsGZWCGuQIMI-ARqDc6FL8t24QXWl1_6UxRrHySgphN4g?key=QS1yYzRLa2g5Q20wQkl4cmlRNElOVzhSTnowY19B
